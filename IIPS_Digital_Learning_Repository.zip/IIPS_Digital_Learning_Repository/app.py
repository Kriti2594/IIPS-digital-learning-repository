import os
import sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "iips.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"pdf", "doc", "docx", "ppt", "pptx", "txt", "jpg", "jpeg", "png", "mp4"}

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('student','faculty','admin'))
    );

    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        description TEXT
    );

    CREATE TABLE IF NOT EXISTS resources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        filename TEXT NOT NULL,
        category_id INTEGER NOT NULL,
        uploaded_by INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending',
        upload_date TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(category_id) REFERENCES categories(id),
        FOREIGN KEY(uploaded_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        resource_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        UNIQUE(resource_id, student_id),
        FOREIGN KEY(resource_id) REFERENCES resources(id),
        FOREIGN KEY(student_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        resource_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        comment TEXT NOT NULL,
        date TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(resource_id) REFERENCES resources(id),
        FOREIGN KEY(student_id) REFERENCES users(id)
    );
    """)
    categories = ["DBMS", "Python", "Java", "Web Development", "AI/ML", "Networking", "OOAD", "Data Structures"]
    for category in categories:
        conn.execute("INSERT OR IGNORE INTO categories(name, description) VALUES (?, ?)",
                     (category, f"{category} learning resources"))
    # Demo accounts
    demo_users = [
        ("System Administrator", "admin@iips.com", "admin123", "admin"),
        ("Demo Faculty", "faculty@iips.com", "faculty123", "faculty"),
        ("Demo Student", "student@iips.com", "student123", "student"),
    ]
    for name, email, password, role in demo_users:
        exists = conn.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
        if not exists:
            conn.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                         (name, email, generate_password_hash(password), role))
    conn.commit()
    conn.close()

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("You do not have permission to access this page.", "danger")
                return redirect(url_for("dashboard"))
            return f(*args, **kwargs)
        return wrapper
    return decorator

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.context_processor
def inject_user():
    return {"logged_in": "user_id" in session, "current_user": session}

@app.route("/")
def index():
    conn = get_db()
    resources = conn.execute("""
        SELECT r.*, c.name AS category, u.name AS uploader,
        COALESCE(AVG(rt.rating), 0) AS avg_rating
        FROM resources r
        JOIN categories c ON c.id=r.category_id
        JOIN users u ON u.id=r.uploaded_by
        LEFT JOIN ratings rt ON rt.resource_id=r.id
        WHERE r.status='Approved'
        GROUP BY r.id
        ORDER BY r.id DESC LIMIT 6
    """).fetchall()
    conn.close()
    return render_template("resources.html", resources=resources, home=True)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        role = request.form["role"]
        if not name or not email or not password or role not in ("student", "faculty"):
            flash("Please fill all fields correctly.", "danger")
            return redirect(url_for("register"))
        conn = get_db()
        try:
            conn.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                         (name, email, generate_password_hash(password), role))
            conn.commit()
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email already registered.", "danger")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            flash(f"Welcome, {user['name']}!", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    role = session["role"]
    if role == "student":
        return redirect(url_for("student_dashboard"))
    if role == "faculty":
        return redirect(url_for("faculty_dashboard"))
    return redirect(url_for("admin_dashboard"))

@app.route("/student")
@role_required("student")
def student_dashboard():
    conn = get_db()
    resources = conn.execute("""
        SELECT r.*, c.name AS category, u.name AS uploader,
        COALESCE(AVG(rt.rating), 0) AS avg_rating
        FROM resources r
        JOIN categories c ON c.id=r.category_id
        JOIN users u ON u.id=r.uploaded_by
        LEFT JOIN ratings rt ON rt.resource_id=r.id
        WHERE r.status='Approved'
        GROUP BY r.id ORDER BY r.id DESC
    """).fetchall()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
    conn.close()
    return render_template("dashboard.html", resources=resources, categories=categories, role="student")

@app.route("/faculty")
@role_required("faculty")
def faculty_dashboard():
    conn = get_db()
    resources = conn.execute("""
        SELECT r.*, c.name AS category
        FROM resources r JOIN categories c ON c.id=r.category_id
        WHERE r.uploaded_by=? ORDER BY r.id DESC
    """, (session["user_id"],)).fetchall()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
    conn.close()
    return render_template("dashboard.html", resources=resources, categories=categories, role="faculty")

@app.route("/admin")
@role_required("admin")
def admin_dashboard():
    conn = get_db()
    users = conn.execute("SELECT id,name,email,role FROM users ORDER BY id DESC").fetchall()
    resources = conn.execute("""
        SELECT r.*, c.name AS category, u.name AS uploader
        FROM resources r JOIN categories c ON c.id=r.category_id
        JOIN users u ON u.id=r.uploaded_by ORDER BY r.id DESC
    """).fetchall()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
    stats = {
        "users": conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "resources": conn.execute("SELECT COUNT(*) FROM resources").fetchone()[0],
        "pending": conn.execute("SELECT COUNT(*) FROM resources WHERE status='Pending'").fetchone()[0],
        "downloads": 0
    }
    conn.close()
    return render_template("admin.html", users=users, resources=resources, categories=categories, stats=stats)

@app.route("/upload", methods=["GET", "POST"])
@role_required("faculty")
def upload():
    conn = get_db()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
    if request.method == "POST":
        title = request.form["title"].strip()
        description = request.form["description"].strip()
        category_id = request.form["category_id"]
        file = request.files.get("file")
        if not title or not category_id or not file or file.filename == "":
            flash("Title, category and file are required.", "danger")
            conn.close()
            return redirect(url_for("upload"))
        if not allowed_file(file.filename):
            flash("File type is not allowed.", "danger")
            conn.close()
            return redirect(url_for("upload"))
        filename = secure_filename(file.filename)
        # Avoid overwriting an existing file
        base, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(os.path.join(UPLOAD_FOLDER, filename)):
            filename = f"{base}_{counter}{ext}"
            counter += 1
        file.save(os.path.join(UPLOAD_FOLDER, filename))
        conn.execute("""
            INSERT INTO resources(title,description,filename,category_id,uploaded_by,status)
            VALUES(?,?,?,?,?,'Pending')
        """, (title, description, filename, category_id, session["user_id"]))
        conn.commit()
        conn.close()
        flash("Resource uploaded and sent for admin approval.", "success")
        return redirect(url_for("faculty_dashboard"))
    conn.close()
    return render_template("upload.html", categories=categories)

@app.route("/search")
@login_required
def search():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "")
    conn = get_db()
    sql = """
        SELECT r.*, c.name AS category, u.name AS uploader,
        COALESCE(AVG(rt.rating),0) AS avg_rating
        FROM resources r
        JOIN categories c ON c.id=r.category_id
        JOIN users u ON u.id=r.uploaded_by
        LEFT JOIN ratings rt ON rt.resource_id=r.id
        WHERE r.status='Approved'
    """
    params = []
    if q:
        sql += " AND (r.title LIKE ? OR r.description LIKE ? OR c.name LIKE ?)"
        like = f"%{q}%"
        params.extend([like, like, like])
    if category:
        sql += " AND r.category_id=?"
        params.append(category)
    sql += " GROUP BY r.id ORDER BY r.id DESC"
    resources = conn.execute(sql, params).fetchall()
    categories = conn.execute("SELECT * FROM categories ORDER BY name").fetchall()
    conn.close()
    return render_template("resources.html", resources=resources, categories=categories, q=q, selected_category=category)

@app.route("/download/<int:resource_id>")
@login_required
def download(resource_id):
    conn = get_db()
    resource = conn.execute("SELECT * FROM resources WHERE id=?", (resource_id,)).fetchone()
    conn.close()
    if not resource or resource["status"] != "Approved":
        abort(404)
    return send_from_directory(UPLOAD_FOLDER, resource["filename"], as_attachment=True)

@app.route("/resource/<int:resource_id>", methods=["GET", "POST"])
@login_required
def resource_detail(resource_id):
    conn = get_db()
    resource = conn.execute("""
        SELECT r.*, c.name AS category, u.name AS uploader,
        COALESCE(AVG(rt.rating),0) AS avg_rating,
        COUNT(rt.id) AS rating_count
        FROM resources r
        JOIN categories c ON c.id=r.category_id
        JOIN users u ON u.id=r.uploaded_by
        LEFT JOIN ratings rt ON rt.resource_id=r.id
        WHERE r.id=? GROUP BY r.id
    """, (resource_id,)).fetchone()
    if not resource:
        conn.close()
        abort(404)
    if request.method == "POST" and session["role"] == "student":
        rating = int(request.form["rating"])
        comment = request.form["comment"].strip()
        conn.execute("""
            INSERT INTO ratings(resource_id,student_id,rating) VALUES(?,?,?)
            ON CONFLICT(resource_id,student_id) DO UPDATE SET rating=excluded.rating
        """, (resource_id, session["user_id"], rating))
        if comment:
            conn.execute("INSERT INTO feedback(resource_id,student_id,comment) VALUES(?,?,?)",
                         (resource_id, session["user_id"], comment))
        conn.commit()
        flash("Thank you for your rating and feedback.", "success")
        return redirect(url_for("resource_detail", resource_id=resource_id))
    feedback = conn.execute("""
        SELECT f.*, u.name FROM feedback f JOIN users u ON u.id=f.student_id
        WHERE f.resource_id=? ORDER BY f.id DESC
    """, (resource_id,)).fetchall()
    conn.close()
    return render_template("resource_detail.html", resource=resource, feedback=feedback)

@app.route("/admin/resource/<int:resource_id>/<action>")
@role_required("admin")
def resource_action(resource_id, action):
    if action not in ("approve", "reject", "delete"):
        abort(400)
    conn = get_db()
    resource = conn.execute("SELECT * FROM resources WHERE id=?", (resource_id,)).fetchone()
    if not resource:
        conn.close()
        abort(404)
    if action == "approve":
        conn.execute("UPDATE resources SET status='Approved' WHERE id=?", (resource_id,))
        flash("Resource approved.", "success")
    elif action == "reject":
        conn.execute("UPDATE resources SET status='Rejected' WHERE id=?", (resource_id,))
        flash("Resource rejected.", "warning")
    else:
        conn.execute("DELETE FROM ratings WHERE resource_id=?", (resource_id,))
        conn.execute("DELETE FROM feedback WHERE resource_id=?", (resource_id,))
        conn.execute("DELETE FROM resources WHERE id=?", (resource_id,))
        filepath = os.path.join(UPLOAD_FOLDER, resource["filename"])
        if os.path.exists(filepath):
            os.remove(filepath)
        flash("Resource deleted.", "success")
    conn.commit()
    conn.close()
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/category/add", methods=["POST"])
@role_required("admin")
def add_category():
    name = request.form["name"].strip()
    description = request.form["description"].strip()
    if name:
        conn = get_db()
        try:
            conn.execute("INSERT INTO categories(name,description) VALUES(?,?)", (name, description))
            conn.commit()
            flash("Category added.", "success")
        except sqlite3.IntegrityError:
            flash("Category already exists.", "danger")
        conn.close()
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/user/<int:user_id>/delete")
@role_required("admin")
def delete_user(user_id):
    if user_id == session["user_id"]:
        flash("You cannot delete your own account.", "danger")
        return redirect(url_for("admin_dashboard"))
    conn = get_db()
    user = conn.execute("SELECT role FROM users WHERE id=?", (user_id,)).fetchone()
    if user:
        # Remove resources uploaded by this faculty first
        resources = conn.execute("SELECT id,filename FROM resources WHERE uploaded_by=?", (user_id,)).fetchall()
        for r in resources:
            conn.execute("DELETE FROM ratings WHERE resource_id=?", (r["id"],))
            conn.execute("DELETE FROM feedback WHERE resource_id=?", (r["id"],))
            path = os.path.join(UPLOAD_FOLDER, r["filename"])
            if os.path.exists(path):
                os.remove(path)
        conn.execute("DELETE FROM resources WHERE uploaded_by=?", (user_id,))
        conn.execute("DELETE FROM ratings WHERE student_id=?", (user_id,))
        conn.execute("DELETE FROM feedback WHERE student_id=?", (user_id,))
        conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        conn.commit()
        flash("User deleted.", "success")
    conn.close()
    return redirect(url_for("admin_dashboard"))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    conn = get_db()
    user = conn.execute("SELECT id,name,email,role FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if request.method == "POST":
        name = request.form["name"].strip()
        password = request.form["password"]
        if name:
            if password:
                conn.execute("UPDATE users SET name=?,password=? WHERE id=?",
                             (name, generate_password_hash(password), session["user_id"]))
            else:
                conn.execute("UPDATE users SET name=? WHERE id=?", (name, session["user_id"]))
            conn.commit()
            session["name"] = name
            flash("Profile updated.", "success")
            user = conn.execute("SELECT id,name,email,role FROM users WHERE id=?", (session["user_id"],)).fetchone()
    conn.close()
    return render_template("profile.html", user=user)

@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
